/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema_hotel;

import Reportes.GenerarPDF;

/**
 *
 * @author redbi
 */
public class Sistema_Hotel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Login log = new Login();
       Inicio init  = new Inicio();
       //Agregar_Empleado ae = new Agregar_Empleado(null,true);
      //GenerarPDF gpdf = new GenerarPDF();
      //gpdf.crearPDF(7, "Alberto Clavijo Baez", "alberto@gmail.com");
    }
    
}
